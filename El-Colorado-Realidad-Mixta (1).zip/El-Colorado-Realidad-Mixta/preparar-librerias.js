/* Copia Three.js y MediaPipe Pose dentro de libs/ para que el juego funcione SIN conexión.
   Se ejecuta solo después de `npm install` (una vez, con internet). */
const fs = require('fs');
const path = require('path');

const raiz = __dirname;
const libs = path.join(raiz, 'libs');
const poseDestino = path.join(libs, 'pose');
fs.mkdirSync(poseDestino, { recursive: true });

function buscar(...candidatos) {
  for (const c of candidatos) { const p = path.join(raiz, 'node_modules', c); if (fs.existsSync(p)) return p; }
  return null;
}

// Three.js (la versión 0.159 todavía trae el archivo único three.min.js)
const three = buscar('three/build/three.min.js');
if (!three) { console.error('No encontré three/build/three.min.js. ¿Corriste "npm install"?'); process.exit(1); }
fs.copyFileSync(three, path.join(libs, 'three.min.js'));
console.log('✔ libs/three.min.js');

// MediaPipe Pose (incluye el modelo de segmentación de la silueta)
const poseDir = buscar('@mediapipe/pose');
if (!poseDir) { console.error('No encontré @mediapipe/pose. ¿Corriste "npm install"?'); process.exit(1); }
let n = 0;
for (const f of fs.readdirSync(poseDir)) {
  if (/\.(js|wasm|data|tflite|binarypb)$/.test(f) && !/heavy/.test(f) && !/\.d\.ts$/.test(f)) {
    fs.copyFileSync(path.join(poseDir, f), path.join(poseDestino, f)); n++;
  }
}
console.log('✔ libs/pose/ (' + n + ' archivos)');
console.log('\nListo. Para jugar: doble clic en INICIAR-JUEGO (o "node servidor.js") y abrí http://localhost:8080 en Chrome.');
