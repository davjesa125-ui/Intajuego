@echo off
cd /d "%~dp0"
if not exist libs\three.min.js (
  echo Primera vez: se instalan las bibliotecas ^(hace falta internet^)...
  call npm install
)
node servidor.js
pause
