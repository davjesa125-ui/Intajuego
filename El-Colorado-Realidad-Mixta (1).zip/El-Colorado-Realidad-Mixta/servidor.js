/* Servidor local mínimo (sin dependencias): sirve esta carpeta en http://localhost:8080
   Hace falta porque Chrome no deja cargar el reconocimiento del cuerpo desde un archivo suelto.
   Todo queda en tu computadora: no se sube nada a internet. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const raiz = __dirname;
const tipos = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.wasm': 'application/wasm', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.data': 'application/octet-stream', '.tflite': 'application/octet-stream', '.binarypb': 'application/octet-stream'
};

function servir(puerto) {
  const srv = http.createServer((req, res) => {
    let ruta = decodeURIComponent(req.url.split('?')[0]);
    if (ruta.endsWith('/')) ruta += 'index.html';
    const archivo = path.normalize(path.join(raiz, ruta));
    if (!archivo.startsWith(raiz) || archivo.includes('node_modules')) { res.writeHead(403); return res.end('No'); }
    fs.readFile(archivo, (err, datos) => {
      if (err) { res.writeHead(404); return res.end('No encontrado'); }
      res.writeHead(200, { 'Content-Type': tipos[path.extname(archivo).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(datos);
    });
  });
  srv.on('error', e => { if (e.code === 'EADDRINUSE' && puerto < 8090) servir(puerto + 1); else console.error(e); });
  srv.listen(puerto, '127.0.0.1', () => {
    const url = 'http://localhost:' + puerto + '/';
    console.log('\n  El Colorado · realidad mixta\n  Abrí Chrome en: ' + url + '\n  (para cerrar: Ctrl + C)\n');
    const abrir = process.platform === 'win32' ? 'start ""' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    exec(abrir + ' ' + url, () => {});
  });
}
servir(8080);
