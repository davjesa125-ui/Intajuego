#!/bin/sh
cd "$(dirname "$0")"
[ -f libs/three.min.js ] || { echo "Primera vez: se instalan las bibliotecas (hace falta internet)..."; npm install; }
node servidor.js
